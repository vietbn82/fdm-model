Canon Speedlite 580EX II Diffuser by Fexxy8 on Thingiverse: https://www.thingiverse.com/thing:6916551

Summary:
A light diffuser for Canon Speedlite 580EX II.I've uploaded a fusion360 .f3d file so you can customise thickness etc.Use transparent material. (I used PETG)Print with 10-30% infill. I used honeycomb pattern. U can also use grid or gyroid (or sth similar).5 top/bottom layers3 wall perimiters0.2 layer heightWhen attaching it to the flash it shouldn't go all the way down (there should be a gap between the flash and diffusor inside).It does the job :)